from Database.Conexion import Conexion

class Consultas_noticias:
    @classmethod
    def insertar_noticia(cls,titulo,descripcion):
        try:
            cursor = Conexion.obtener_conexion()
            cursor.execute("INSERT INTO `noticias`(`titulo`, `descripcion`) VALUES ('{0}','{1}')".format(titulo,descripcion))
            cursor.connection.commit()
        
        except Exception as e:
            return e
        
        finally:
            cursor.close()
    
    @classmethod
    def listar_noticias(cls):
        try:
            cursor = Conexion.obtener_conexion()
            cursor.execute("SELECT * FROM `noticias`")
            noticias = cursor.fetchall()

            return noticias

        except Exception as e:
            return e
        
        finally :
            cursor.close()

    @classmethod
    def buscar_noticia(cls,id_noticia):
        try:
            cursor = Conexion.obtener_conexion()
            cursor.execute("SELECT * FROM `noticias` WHERE id_noticia = '{0}'".format(id_noticia))
            noticia = cursor.fetchone()

            return noticia

        except Exception as e:
            return e

        finally:
            cursor.close() 
    
    @classmethod
    def eliminar_noticia(cls,titulo):
        try:
            cursor = Conexion.obtener_conexion()
            cursor.execute("DELETE FROM `noticias` WHERE titulo = '{0}'".format(titulo))
            cursor.connection.commit()
        
        except Exception as e:
            return e
        
        finally:
             cursor.close()
    
    @classmethod
    def actualizar_noticia(cls,titulo,descripcion,titulo_nuevo):
        try:
            cursor = Conexion.obtener_conexion()
            cursor.execute("UPDATE `noticias` SET `titulo`='{0}',`descripcion`='{1}' WHERE titulo = '{2}'".format(titulo_nuevo,descripcion,titulo))
            cursor.connection.commit()

        except Exception as e:
            return e
        
        finally:
             cursor.close()
    
    @classmethod
    def agregar_comentario(cls,id_noticia,comentario):
        try:
            cursor = Conexion.obtener_conexion()
            cursor.execute("INSERT INTO `comentarios`(`id_noticia`, `comentario`) VALUES ('{0}','{1}')".format(id_noticia,comentario))
            cursor.connection.commit()

        except Exception as e:
            return e
        
        finally :
            cursor.close()