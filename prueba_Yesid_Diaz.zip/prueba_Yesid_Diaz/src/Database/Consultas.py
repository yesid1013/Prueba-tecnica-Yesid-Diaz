from Database.Conexion import Conexion

class Consultas :

    @classmethod
    def insertar_usuario(cls,nombre,correo,contraseña,direccion,telefono,fecha_nacimiento):
        try:
            cursor = Conexion.obtener_conexion()
            cursor.execute("INSERT INTO `usuarios`(`nombre`, `correo`, `contraseña`, `direccion`, `telefono`, `fecha_nacimiento`) VALUES ('{0}','{1}','{2}','{3}','{4}','{5}')".format(nombre,correo,contraseña,direccion,telefono,fecha_nacimiento))
            cursor.connection.commit()

        except Exception as e:
            return e
        
        finally:
            cursor.close()

    @classmethod
    def buscar_correo(cls,correo):
        try:
            cursor = Conexion.obtener_conexion()
            cursor.execute("SELECT * FROM `usuarios` WHERE correo = '{0}'".format(correo))
            user = cursor.fetchone()

            return user
        
        except Exception as e:
            return e
        
        finally :
            cursor.close()
    
    @classmethod
    def login(cls,correo,contraseña):
        try:
            cursor = Conexion.obtener_conexion()
            cursor.execute("SELECT * FROM `usuarios` WHERE correo = '{0}' AND contraseña = '{1}'".format(correo,contraseña))
            user = cursor.fetchone()

            return user

        except Exception as e:
            return e
        
        finally :
            cursor.close()
