import pymysql

class Conexion :
    @classmethod
    def obtener_conexion(cls):
        try:
            conexion = pymysql.connect(
                host="localhost", user="root", password="", db= "red5g"
            )

            return conexion.cursor()

        except Exception as e:
            return e
