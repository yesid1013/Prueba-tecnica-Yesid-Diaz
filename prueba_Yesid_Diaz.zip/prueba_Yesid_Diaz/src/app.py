from flask import Flask,jsonify,request, session
from Clases.Usuarios import Usuarios
from Clases.Noticias import Noticias

app = Flask(__name__)

app.secret_key = 'esto-es-una-clave-muy-secreta'

@app.before_request
def sesion ():
    ruta = request.path
    if not 'usuario' in session and ruta != '/login':
        return {"message" :"por favor inicie sesion" , "status" : 400} , 400

@app.route('/insertar_usuario', methods = ['POST'])
def insertar_usuario():
    try:
        data = Usuarios.insertar_usuario(request.json['nombre'],request.json['correo'],request.json['contraseña'],request.json['direccion'],request.json['telefono'],request.json['fecha_nacimiento'])

        if data['status'] != 200:
            return jsonify({"message":data['message'], "status": data['status']}) , data['status']
        
        return jsonify(data) , data['status']

    except Exception as e:
        return e

@app.route('/login',methods = ['POST'])
def login():
    try:
        data = Usuarios.login(request.json['correo'],request.json['contraseña'])

        if data['status'] != 200:
            return jsonify({"message":data['message'], "status": data['status']}) , data['status']
        
        return jsonify(data) , data['status']

    except Exception as e:
        return e

@app.route('/insertar_noticia', methods = ['POST'])
def insertar_noticia ():
    try:
        data =Noticias.insertar_noticia(request.json['titulo'],request.json['descripcion'])

        if data['status'] != 200:
            return jsonify({"message":data['message'], "status": data['status']}) , data['status']
        
        return jsonify(data) , data['status']

    except Exception as e:
        return e

@app.route('/listar_noticias', methods= ['GET'])
def listar_noticias () :
    try:
        data = Noticias.listar_noticias()

        if data['status'] != 200:
            return jsonify({"message":data['message'], "status": data['status']}) , data['status']
        
        return jsonify(data) , data['status']

    except Exception as e:
        return e

@app.route('/eliminar_noticia/<titulo>', methods = ['DELETE'])
def eliminar_noticia (titulo):
    try:
        data = Noticias.eliminar_noticia(titulo)

        if data['status'] != 200:
            return jsonify({"message":data['message'], "status": data['status']}) , data['status']
        
        return jsonify(data) , data['status']

    except Exception as e:
        return e

@app.route('/actualizar_noticia/<titulo>', methods = ['PUT'])
def actualizar_noticia(titulo):
    try:
        data = Noticias.actualizar_noticia(titulo,request.json['descripcion'],request.json['titulo_nuevo'])

        if data['status'] != 200:
            return jsonify({"message":data['message'], "status": data['status']}) , data['status']
        
        return jsonify(data) , data['status']

    except Exception as e:
        return e

@app.route('/agregar_comentario/<int:id>', methods= ['POST'])
def agregar_comentario(id):
    try:
        data = Noticias.agregar_comentario(id,request.json['comentario'])

        if data['status'] != 200:
            return jsonify({"message":data['message'], "status": data['status']}) , data['status']
        
        return jsonify(data) , data['status']

    except Exception as e:
        return e



if __name__ == '__main__':
    app.run(debug=True)
