from Database.Consultas import Consultas
from flask import session

class Usuarios :

    @classmethod
    def insertar_usuario(cls,nombre,correo,contraseña,direccion,telefono,fecha_nacimiento):
        try:
            user = Consultas.buscar_correo(correo)
            if user != None:
                return {"message" : "El correo ya se encuentra registrado", "status": 400}

            else:
                Consultas.insertar_usuario(nombre,correo,contraseña,direccion,telefono,fecha_nacimiento)
                return {"message":"insercion exitosa", "status": 200}

        except Exception as e:
            return {"message":str(e), "status": 500}
    
    @classmethod
    def login(cls,correo,contraseña):
        try:
            user = Consultas.login(correo,contraseña)
            
            if user != None:
                session["usuario"] = correo
                return {"message":"Inicio de sesion exitoso", "status": 200}
            else:
                return {"message": "Credenciales incorrectas", "status": 400}
                
        except Exception as e:
            return {"message":str(e), "status": 500}
    