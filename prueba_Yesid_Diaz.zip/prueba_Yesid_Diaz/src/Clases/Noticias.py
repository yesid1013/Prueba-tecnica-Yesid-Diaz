from Database.Consultas_noticias import Consultas_noticias

class Noticias :

    @classmethod
    def insertar_noticia(cls,titulo,descripcion):
        try:
            if type(titulo) == str and type(descripcion) == str:

                Consultas_noticias.insertar_noticia(titulo,descripcion)
                return {"message": "Noticia insertada correctamente", "status" : 200}
            
            else:
                return {"message" : "Los datos son incorrectos" , "status" : 400}

        except Exception as e:
            return {"message":str(e), "status": 500}
    
    @classmethod
    def listar_noticias(cls):
        try:
            noticias = []
            datos = Consultas_noticias.listar_noticias()

            if len(datos) != 0:
                for dato in datos:
                    contenido =  {"Titulo" : dato[0], "Descripcion" : dato[1]}
                    noticias.append(contenido)
                
                return {"message" : "Servicio exitoso" , "status" : 200, "Noticias" : noticias}
            else :
                return {"message" : "No hay noticias registradas" , "status" : 404}

        except Exception as e:
            return {"message":str(e), "status": 500}
    
    @classmethod
    def eliminar_noticia (cls,titulo):
        try:
            noticia = Consultas_noticias.buscar_noticia(titulo)

            if noticia != None:
                Consultas_noticias.eliminar_noticia(titulo)
                return {"message" : "Eliminacion exitosa" , "status" : 200}
            else:
                return {"message" : "Noticia no encontrada", "status" : 404}
                

        except Exception as e:
            return {"message":str(e), "status": 500}

    @classmethod
    def actualizar_noticia(cls,titulo,descripcion,titulo_nuevo):
        try:
            if type(titulo) == str and type(descripcion) == str and type(titulo_nuevo) == str:

                noticia = Consultas_noticias.buscar_noticia(titulo)

                if noticia != None:
                    Consultas_noticias.actualizar_noticia(titulo,descripcion,titulo_nuevo)
                    return {"message" : "Actualizacion exitosa", "status":200}
                else:
                    return {"message" : "Noticia no encontrada", "status" : 404}
            
            else:
                return {"message" : "Los datos son incorrectos" , "status" : 400}

        except Exception as e :
            return {"message":str(e), "status": 500}
    
    @classmethod
    def agregar_comentario(cls,id_noticia,comentario):
        try:
            if type(id_noticia) == int and type(comentario) == str:

                noticia = Consultas_noticias.buscar_noticia(id_noticia)

                if noticia != None:
                    Consultas_noticias.agregar_comentario(id_noticia,comentario)
                    return {"message" : "Comentario agregado exitosamente", "status": 200}

                else:
                    return {"message" : "Noticia no encontrada", "status" : 404}
            else: 
                return {"message" : "Los datos son incorrectos", "status" : 400}
        
        except Exception as e:
            return {"message":str(e), "status": 500}



